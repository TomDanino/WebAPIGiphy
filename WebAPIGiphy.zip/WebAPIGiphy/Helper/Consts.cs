﻿namespace WebAPIGiphy
{
    public class Consts
    {
        public const string API_KEY = "2vXkUpZQQ74N7nz4LkUFpX17szx8DI9s";
        public const string URL_SEARCH = "http://api.giphy.com/v1/gifs/search";
        public const int CACHE_SEARCH_TIMEOUT_HOURS = 24;
    }
}