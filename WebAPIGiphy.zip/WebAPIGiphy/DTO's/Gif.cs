﻿namespace WebAPIGiphy
{
    public class Gif
    {
        public string url { get; set; }

    }
}