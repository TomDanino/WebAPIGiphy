﻿using System.Collections.Generic;

namespace WebAPIGiphy
{
    public class RootObject
    {
        public List<Gif> data { get; set; }
    }
}